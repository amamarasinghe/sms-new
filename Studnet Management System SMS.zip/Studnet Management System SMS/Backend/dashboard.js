function showAddStudentForm() {
    document.getElementById('add-student-form').style.display = 'block';
}
